@extends('admin_layout')
@section('admin_content')
<h3>Chào mừng bạn đến với Admin</h3>
@endsection